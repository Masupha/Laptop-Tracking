#from tkinter.messagebox import showwarning
import openpyxl
import gspread
from openpyxl import Workbook
import subprocess
from datetime import datetime
#showwarning

def get_serial_number():
    # Use the appropriate method to fetch the serial number based on the Linux distribution
    # For Ubuntu and Debian-based distributions:
    try:
        output = subprocess.check_output("sudo dmidecode -s system-serial-number", shell=True)
        return output.decode().strip()
    except subprocess.CalledProcessError:
        return None
    # For Red Hat, CentOS, and Fedora-based distributions:
    # try:
    #     output = subprocess.check_output("sudo cat /sys/class/dmi/id/product_serial", shell=True)
    #     return output.decode().strip()
    # except subprocess.CalledProcessError:
    #     return None
    

def write_serial_number_to_excel(serial_number):
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    

    wb = Workbook()
    sheet = wb.active
    sheet["A1"] = "Serial Number"
    sheet["A2"] = serial_number
    sheet["B1"] = "Facility"
    sheet["B2"] = "HomeMade HC"
    sheet["C1"] = "Last Seen"
    sheet["C2"] = current_time
    output_filename = "serial_number.xlsx"
    wb.save(output_filename)

if __name__ == "__main__":
    serial_number = get_serial_number()
    if serial_number:
        write_serial_number_to_excel(serial_number)
        print("Serial number has been written to 'serial_number.xlsx' successfully.")
    else:
        print("Failed to fetch the serial number.")

sa = gspread.service_account(filename="/usr/local/bin/laptop-tracking-402818-2f7ba8fdfc10")
sp = sa.open("LaptopTrackingQachasNek")
sheet = sp.worksheet("MachabengHospital")
current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
sheet.update('D3',current_time)
