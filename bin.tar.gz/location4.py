import gspread
from oauth2client.service_account import ServiceAccountCredentials
from datetime import datetime

# Replace these values with your own
SPREADSHEET_NAME = 'ICAP Laptops Online Activity Tracking Testing'
CREDENTIALS_FILE = '/usr/local/bin/laptop-tracker-380206-edb321b38471.json'
SHEET_NAME = 'HolyFamilyHC'

# Authorize with Google Sheets API
scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
credentials = ServiceAccountCredentials.from_json_keyfile_name(CREDENTIALS_FILE, scope)
gc = gspread.authorize(credentials)

# Open the Google Sheets document
worksheet = gc.open(SPREADSHEET_NAME).worksheet(SHEET_NAME)

# Get the current time
current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

# Write the last seen time to the Google Sheets document
worksheet.update_acell('D2', f'{current_time}')

print(f'Last Seen Time updated: {current_time}')

